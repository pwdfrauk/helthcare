// mobile menu onClick support js function
/*plain js code */
function openNav() {
	document.getElementById('mobilenav').style.width = "100%";
	console.log('open nav is cliking');
};
function clossNav() {
	document.getElementById('mobilenav').style.width = "0%";
	console.log('mobile nav is closing')
};